import { Component } from '@angular/core';

@Component({
  selector: 'ngx-editors',
  template: `
    <router-outlet></router-outlet>
  `,
})
export class EditorsComponent {

}
